import 'dart:io';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled1/main.dart';

class AddSectionScreen extends StatefulWidget {
  const AddSectionScreen({super.key});

  @override
  State<AddSectionScreen> createState() => _AddSectionScreenState();
}

class _AddSectionScreenState extends State<AddSectionScreen> {
  List<List<dynamic>> _excelData = [];

  Future<void> pickAndReadExcelFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls'],
    );

    if (result != null) {
      File file = File(result.files.single.path!);
      var bytes = file.readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);

      setState(() {
        _excelData.clear();
        for (var table in excel.tables.keys) {
          var sheet = excel.tables[table]!;
          for (var row in sheet.rows) {
            _excelData.add(row);
          }
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'إضافة شعبة جديدة',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: height(context) * 0.01,
            ),
            Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xff1f5e15),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        spreadRadius: 0.3,
                        blurRadius: 9,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  height: height(context) * 0.075,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(right: 11.0, top: 8),
                    child: Text(
                      'أختر المادة',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.black12,
                  ),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'CPC5351',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: width(context) * 0.9,
                  child: const Divider(
                    color: Colors.black,
                    height: 0,
                    thickness: 1,
                    indent: 0,
                    endIndent: 0,
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.black12,
                  ),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'CPC5351',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: width(context) * 0.9,
                  child: const Divider(
                    color: Colors.black,
                    height: 0,
                    thickness: 1,
                    indent: 0,
                    endIndent: 0,
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.black12,
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10))),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'CPC5351',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: height(context) * 0.03,
            ),
            Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xff1f5e15),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        spreadRadius: 0.3,
                        blurRadius: 9,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  height: height(context) * 0.075,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(right: 11.0, top: 8),
                    child: Text(
                      'أختر الشعبة',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.black12,
                  ),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'DAR',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: width(context) * 0.9,
                  child: const Divider(
                    color: Colors.black,
                    height: 0,
                    thickness: 0.7,
                    indent: 0,
                    endIndent: 0,
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.black12,
                  ),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'BAR',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: width(context) * 0.9,
                  child: const Divider(
                    color: Colors.black,
                    height: 0,
                    thickness: 0.8,
                    indent: 0,
                    endIndent: 0,
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Colors.black12,
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10))),
                  height: height(context) * 0.04,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(left: 11.0, top: 5),
                    child: Text(
                      'FAR',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: height(context) * 0.03,
            ),
            Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xff1f5e15),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        spreadRadius: 0.3,
                        blurRadius: 9,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  height: height(context) * 0.075,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(right: 11.0, top: 8),
                    child: Text(
                      'أضف أسماء الطالبات',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                      color: Color(0xffcdedcb),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10))),
                  height: height(context) * 0.1,
                  width: width(context) * 0.9,
                  child: Center(
                    child: Container(
                      height: height(context) * 0.04,
                      width: width(context) * 0.45,
                      decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.4),
                              spreadRadius: 0.3,
                              blurRadius: 9,
                              offset: const Offset(0, 3),
                            ),
                          ],
                          color: const Color(0xffb0e4ab),
                          borderRadius: BorderRadius.circular(20)),
                      child:  Center(
                        child: GestureDetector(
                          onTap: () {
                             pickAndReadExcelFile();
                          },
                          child: const Text(
                            'Attach a file',
                            style: TextStyle(
                                color: Color(0xff1f5e15),
                                fontSize: 15),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: height(context) * 0.03,
            ),
            Padding(
              padding: EdgeInsets.only(bottom: height(context) * 0.04),
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  height: height(context) * 0.04,
                  width: width(context) * 0.5,
                  decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(20)),
                  child: const Center(
                    child: Text(
                      'Done',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: 20
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: height(context)*0.003,),
            Padding(
              padding:  EdgeInsets.only(left: width(context)*0.13,right: width(context)*0.13),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: [
                  IconButton(icon:
                  const Icon(Icons.menu,size: 40,),
                    onPressed: () {

                    },),
                  SizedBox(width: width(context)*0.12,),
                  IconButton(icon:
                  const Icon(Icons.arrow_back,size: 40,),
                    onPressed: () {
                      Navigator.pop(context);
                    },),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
