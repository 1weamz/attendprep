import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:pretty_qr_code/pretty_qr_code.dart';

import 'main.dart';

class BarCodeScreen extends StatefulWidget {
  const BarCodeScreen({super.key});

  static const String screenRoute = '/barcode';

  @override
  State<BarCodeScreen> createState() => _BarCodeScreenState();
}

class _BarCodeScreenState extends State<BarCodeScreen> {
  Random random = Random();
  int? randomNumber;
  late QrImage qrImage;
  int count = 20;
  late Timer timer;

  void qr({required String userData}) {
    final qrCode = QrCode(
      3,
      QrErrorCorrectLevel.H,
    )..addData(userData);

    qrImage = QrImage(qrCode);
  }

  @override
  void didChangeDependencies() {
    qr(userData: '{"True"}');
    timer = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      setState(() {
        if (count > 0) {
          count--;
          if (count == 0) {
            Navigator.pop(context);
          }
        } else {
          timer.cancel();
        }
      });
    });
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: height(context) * 0.1,
            ),
            Expanded(
                flex: 2,
                child: Container(
                  width: width(context) * 0.6,
                  height: height(context) * 0.3,
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(width(context) * 0.03),
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: PrettyQrView(
                    qrImage: qrImage,
                    decoration: const PrettyQrDecoration(),
                  ),
                )),
            SizedBox(
              height: height(context) * 0.2,
            ),
            Expanded(
                flex: 2,
                child: RichText(
                  text: TextSpan(
                      text: '$count',
                      style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                          fontSize: 50)),
                )),
            Padding(
              padding: EdgeInsets.only(bottom: height(context) * 0.04),
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  height: height(context) * 0.04,
                  width: width(context) * 0.45,
                  decoration: BoxDecoration(
                      color: Color(0xff1f5e15),
                      borderRadius: BorderRadius.circular(20)),
                  child: const Center(
                      child: Text(
                        'Done',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: 20
                        ),
                      ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
