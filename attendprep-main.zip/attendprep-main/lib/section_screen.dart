import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:untitled1/qr_code_screen.dart';

import 'main.dart';

class SectionScreen extends StatefulWidget {
  const SectionScreen({super.key});

  @override
  State<SectionScreen> createState() => _SectionScreenState();
}

class _SectionScreenState extends State<SectionScreen> {
  Future<void> createExcel() async {
    // إنشاء ملف Excel جديد
    var excel = Excel.createExcel();
    // الحصول على ورقة Excel الأولى
    Sheet sheetObject = excel['Sheet1'];

    // إضافة البيانات إلى ورقة Excel
    List<List<dynamic>> data = [
      ['Name', 'Age', 'Gender'],
      ['John Doe', 30, 'Male'],
      ['Jane Doe', 28, 'Female'],
      ['Sam Smith', 35, 'Male']
    ];

    for (var row in data) {
      sheetObject.appendRow(row.map((item) {}).toList());
    }

    // حفظ الملف في الجهاز
    Directory? directory = await getExternalStorageDirectory();
    String outputPath = '${directory?.path}/example.xlsx';
    var fileBytes = excel.save();
    if (fileBytes != null) {
      File(outputPath)
        ..createSync(recursive: true)
        ..writeAsBytesSync(fileBytes);
      print('File saved at $outputPath');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Text(
              'HAD - رياضيات عامة ',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: height(context) * 0.03,
            ),
            Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xff1f5e15),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        spreadRadius: 0.3,
                        blurRadius: 9,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  height: height(context) * 0.075,
                  width: width(context) * 0.9,
                  child: const Padding(
                    padding: EdgeInsets.only(right: 11.0, top: 8),
                    child: Text(
                      'اسماء الطالبات ',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.black12,
                  ),
                  height: height(context) * 0.3,
                  width: width(context) * 0.9,
                  child:  Padding(
                    padding: const EdgeInsets.only(left: 11.0,right: 12),
                    child: ListView.separated(
                        itemBuilder: (context, index) =>  const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.grey,
                              ),
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.green,
                              ),
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.red,
                              ),
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.green,
                              ),
                              Text(
                                'نجود الوهيبي',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold
                                ),
                              ),
                            ],
                          ),
                        )
                        , separatorBuilder: (context, index) => SizedBox(
                      width: width(context) * 0.1,
                      child: const Divider(
                        color: Colors.black,
                        height: 0,
                        thickness: 1,
                        indent: 0,
                        endIndent: 0,
                      ),
                    ),
                        itemCount: 4),
                  ),
                ),

              ],
            ),
            SizedBox(
              height: height(context) * 0.09,
            ),
            Container(
              height: height(context) * 0.05,
              width: width(context) * 0.45,
              decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      spreadRadius: 0.3,
                      blurRadius: 9,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  color: const Color(0xffb0e4ab),
                  borderRadius: BorderRadius.circular(20)),
              child:  Center(
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const BarCodeScreen(),)
                    );
                  },
                  child: const Text(
                    'أنشئ باركود',
                    style: TextStyle(
                        color: Color(0xff1f5e15),
                        fontSize: 15,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: height(context) * 0.03,
            ),
            Container(
              height: height(context) * 0.05,
              width: width(context) * 0.45,
              decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      spreadRadius: 0.3,
                      blurRadius: 9,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  color: const Color(0xffb0e4ab),
                  borderRadius: BorderRadius.circular(20)),
              child:  Center(
                child: GestureDetector(
                  onTap: () async {
                    await createExcel();
                  },
                  child: const Text(
                    'انشئ ملف حضور',
                    style: TextStyle(
                        color: Color(0xff1f5e15),
                        fontSize: 15,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
