import 'package:flutter/material.dart';
import 'package:untitled1/scan_qrcode_screen.dart';
import 'package:untitled1/section_screen.dart';

import 'add_section_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
      ),
      debugShowCheckedModeBanner: false,
      home: const SectionScreen(),
    );
  }
}

double width(BuildContext context){
  return MediaQuery.of(context).size.width;
}


double height(BuildContext context){
  return MediaQuery.of(context).size.height;
}