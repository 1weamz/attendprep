import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';

import 'main.dart';


class ScanQRScreen extends StatefulWidget {
  const ScanQRScreen({super.key});

  static const String screenRoute = '/admin-home';

  @override
  State<ScanQRScreen> createState() => _ScanQRScreenState();
}

class _ScanQRScreenState extends State<ScanQRScreen> {
  String scanBarcode = 'Unknown';

  @override
  void initState() {
    super.initState();
  }

  Future<void> scanQR() async {
    String barcodeScanRes;
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.QR);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }
    if (!mounted) return;

    setState(() {
      scanBarcode = barcodeScanRes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(image: const AssetImage('assets/image2.png'),width: width(context)*0.35,),
            SizedBox(height: height(context)*0.12,),
            const Image(image: AssetImage('assets/image1.png')),
            SizedBox(height: height(context)*0.12,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(icon:
                const Icon(Icons.menu,size: 40,),
                  onPressed: () {

                },),
                SizedBox(width: width(context)*0.12,),
                GestureDetector(
                  onTap: () async{
                    await scanQR();
                  },
                  child: CircleAvatar(
                    backgroundColor:const Color(0xff1f5e15),
                    radius: 40,
                    child: Image(image: const AssetImage('assets/image3.png'), width: width(context)*0.14,color: Colors.white,),
                  ),
                ),
                SizedBox(width: width(context)*0.12,),
                IconButton(icon:
                const Icon(Icons.arrow_back,size: 40,),
                  onPressed: () {
                  Navigator.pop(context);
                  },),
              ],
            )
          ],

        ),
      ),
    );
  }
}